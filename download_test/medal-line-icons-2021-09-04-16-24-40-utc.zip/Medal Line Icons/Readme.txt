INTRODUCING
Pixel perfect icon set by Kreev Studio. Perfect for your mobile apps website and presentations

FILES INCLUDED:
- PNG 512px for each file
- SVG for each file
- EPS
- Adobe Illustrator .AI
- Figma .FIG

See more icons at :
https://elements.envato.com/user/mhudaaa/graphics

Mhudaaa supported by Kreev Studio
kreev.studio@gmail.com
kreevstudio.com

Hope you Like it.
Thanks.